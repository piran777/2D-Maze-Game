using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CharacterSpawning : MonoBehaviour
{

    //public GameObject hero;
    //public GameObject healer;
    //public GameObject dwarf;

    public Vector2 currentLocation;


    // Start is called before the first frame update
    void Start()
    {
        //Instantiate(hero, transform.position, Quaternion.identity);
    }

    void FixedUpdate()
    {
        
    }

}
